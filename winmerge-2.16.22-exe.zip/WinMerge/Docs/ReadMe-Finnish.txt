WINMERGE

WinMerge on Open Source vertailu- ja yhdistelyty�kalu Windowsille. WinMerge vertailee kansioita ja tiedostoja, esitt�en erot visuaalisessa tekstimuodossa, jota on helppo ymm�rt�� ja k�sitell�. WinMerge� voidaan k�ytt�� ulkoisena erottelu-/yhdistelyty�kaluna tai itsen�isen� sovelluksena.

WinMergess� on monia hy�dyllisi� tukiominaisuuksia, jotka tekev�t vertailusta, synkronoinnista ja yhdist�misist� niin helppoja ja hy�dyllisi� kuin mahdollista. Useat ohjelmointikielet ja muut tiedostomuodot ovat syntaksikorostettuja.

Uusin WinMerge versio ja tiedot ovat saatavilla osoitteessa https://winmerge.org/.

Pika-aloitus
============
Lis�tietoja WinMergen perustoiminnoista saat klikkaamalla Ohje>WinMerge Ohje ja siirtym�ll� Pikak�ynnistys-aiheisiin. Tai mene verkkoversioon https://manual.winmerge.org/Quick_start.html.

WinMerge Ohje
=============
WinMerge ohje on asennettu paikallisesti asennuksen yhteydess� Microsoft HTML help-tiedostona, WinMerge.chm. Avaa ohje valitsemalla Ohje>WinMerge Ohje tai paina F1 WinMerge-ikkunassa. Komentorivill� suorita WinMerge /? valinnalla.

Voit my�s selata WinMerge ohjeen HTML-versiota sivuilla https://manual.winmerge.org/.

WinMerge tuki
=============
Kysymyksi� tai ehdotuksia WinMergest�? Hyv� paikka aloittaa on WinMerge yhteis�n ilmoitustaulu https://forums.winmerge.org/. Kehitt�j�t lukevat ja vastaavat kysymyksiin molemmilla foorumeilla. K�yt� avointa keskustelufoorumia yleisiin WinMerge-kysymyksiin, kuten kysymyksi� k�yt�st�. K�yt� kehitt�jien foorumia WinMergen tuotekehityskysymyksiin.

Viat ja ominaisuuspyynn�t
=========================
Jos ongelma ei ratkennut WinMerge-foorumeilla, tarkista projektin seuraajista: Siirry https://project.winmerge.org/ ja klikkaa linkki� Trackers-valikosta ->Viat ja pyynn�t, jossa voit selata tai l�hett�� yksityiskohtia.

Jos l�het�t vikailmoituksen, ilmoita WinMergen versionumero raportissasi. Voit luoda kokoonpanolokin valitsemalla Ohje->Kokoonpano. Liit� kokoonpanoloki vikailmoitukseen; siin� on paljon hy�dyllist� tietoa sovelluskehitt�jille.


- WinMerge-kehitt�j�t
